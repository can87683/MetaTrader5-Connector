#!/usr/bin/env python3
# mt5_connector.py

import setproctitle
setproctitle.setproctitle("mt5_connector.py")

import os
import sys
import time
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple, Union
import MetaTrader5 as mt5
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import customtkinter as ctk
import threading
import configparser
from pathlib import Path

# ==================== CENTRALIZED CONFIGURATION ====================
TIMEFRAMES = ["M5", "M15", "H1", "H4", "D1", "W1"]
TIMEFRAME_ORDER = ["M5", "M15", "H1", "H4", "D1", "W1"]
DEFAULT_MAX_BARS = 10000
DEFAULT_DATA_DIR = os.path.join(str(Path.home()), "mt5_data")

# ==================== OS DETECTION ====================
def is_wine() -> bool:
    return os.environ.get("WINELOADERNOEXEC") is not None

def is_windows() -> bool:
    return sys.platform.startswith("win")

def is_wine_or_windows() -> bool:
    return is_wine() or is_windows()

# ==================== CONFIGURATION CLASSES ====================
class ConfigCtk:
    """Centralized CTk theme and style configuration."""

    # Window dimensions
    WIN_W = 640
    WIN_H = 1020
    HEADER_HEIGHT = 52

    # Font configurations - ALL 12pt
    FONT_H = ("Roboto", 12, "bold")
    FONT_S = ("Roboto", 12)
    FONT_MONO = ("Consolas", 12)

    # Appearance
    APPEARANCE_MODE = "dark"
    COLOR_THEME = "dark-blue"

    # Color palette (dark industrial with amber accent)
    BG0 = "#0f1117"      # root / deepest bg
    BG1 = "#181c27"      # frame bg
    BG2 = "#21263a"      # widget bg
    BG3 = "#2c3350"      # hover / active
    ACCENT = "#f5a623"   # amber
    ACCENT2 = "#e07b10"  # amber dark
    FG = "#d4d8e8"       # foreground text
    FG_DIM = "#6b7499"   # dim text
    GREEN = "#3ecf8e"    # success
    RED = "#ff4d6d"      # error
    YELLOW = "#ffd166"   # warning
    DARK_BLUE = "#1e3a8a"  # NEW: Dark blue for button backgrounds

    # Widget styles (without width parameter)
    FRAME_HDR_STYLE = {
        "fg_color": (BG1, BG1),
        "height": HEADER_HEIGHT,
        "corner_radius": 0
    }

    TABVIEW_STYLE = {
        "fg_color": (BG0, BG0),
        "segmented_button_fg_color": (BG1, BG1),
        "segmented_button_selected_color": (ACCENT, ACCENT),
        "segmented_button_selected_hover_color": (ACCENT2, ACCENT2),
        "segmented_button_unselected_color": (BG1, BG1),
        "segmented_button_unselected_hover_color": (BG3, BG3),
        "text_color": (FG, FG),
        "text_color_disabled": (FG_DIM, FG_DIM),
        "corner_radius": 0
    }

    LABEL_HDR_STYLE = {
        "font": FONT_H,
        "text_color": (ACCENT, ACCENT)
    }

    LABEL_SUB_STYLE = {
        "font": FONT_S,
        "text_color": (FG_DIM, FG_DIM)
    }

    BUTTON_PRIMARY_STYLE = {
        "fg_color": DARK_BLUE,      # Changed to dark blue
        "hover_color": "#2e4aad",   # Lighter dark blue on hover
        "text_color": FG,           # Light foreground text
        "font": FONT_S
    }

    BUTTON_SUCCESS_STYLE = {
        "fg_color": DARK_BLUE,      # Changed to dark blue
        "hover_color": "#2e4aad",   # Lighter dark blue on hover
        "text_color": FG,           # Light foreground text
        "font": FONT_S
    }

    BUTTON_DANGER_STYLE = {
        "fg_color": DARK_BLUE,      # Changed to dark blue
        "hover_color": "#2e4aad",   # Lighter dark blue on hover
        "text_color": FG,           # Light foreground text
        "font": FONT_S
    }

    BUTTON_DISABLED_STYLE = {
        "fg_color": BG2,
        "text_color": FG_DIM,
        "font": FONT_S
    }

    ENTRY_STYLE = {
        "fg_color": BG2,
        "text_color": FG,
        "border_color": BG3,
        "border_width": 1,
        "font": FONT_S
    }

    COMBOBOX_STYLE = {
        "fg_color": BG2,
        "text_color": FG,
        "border_color": BG3,
        "button_color": ACCENT,
        "button_hover_color": ACCENT2,
        "dropdown_fg_color": BG1,
        "dropdown_text_color": FG,
        "dropdown_hover_color": BG3,
        "font": FONT_S
    }

    CHECKBOX_STYLE = {
        "fg_color": BG2,
        "border_color": BG3,
        "hover_color": BG3,
        "text_color": FG,
        "font": FONT_S
    }

    TEXTBOX_STYLE = {
        "fg_color": BG1,
        "text_color": YELLOW,
        "border_color": BG3,
        "border_width": 1,
        "font": FONT_MONO
    }

    RATE_LABEL_STYLE = {
        "font": ("Courier", 12, "bold"),
        "text_color": GREEN
    }

    TABLE_HEADER_STYLE = {
        "font": ("Courier", 12, "bold"),
        "text_color": FG
    }

    TABLE_AVAILABLE_STYLE = {
        "font": ("Courier", 12),
        "text_color": "#00FFFF"
    }

    TABLE_FETCHED_STYLE = {
        "font": ("Courier", 12, "bold"),
        "text_color": GREEN
    }

# ==================== MT5 API DIRECT CLASS ====================
class MT5API:
    """Direct MetaTrader5 API implementation - replaces Mt5BridgeClient"""

    # Timeframe constants mapping
    TIMEFRAMES = {
        'M5': mt5.TIMEFRAME_M5,
        'M15': mt5.TIMEFRAME_M15,
        'H1': mt5.TIMEFRAME_H1,
        'H4': mt5.TIMEFRAME_H4,
        'D1': mt5.TIMEFRAME_D1,
        'W1': mt5.TIMEFRAME_W1,
    }

    # Order type mapping
    ORDER_TYPES = {
        'BUY': mt5.ORDER_TYPE_BUY,
        'SELL': mt5.ORDER_TYPE_SELL,
        'BUY_LIMIT': mt5.ORDER_TYPE_BUY_LIMIT,
        'SELL_LIMIT': mt5.ORDER_TYPE_SELL_LIMIT,
        'BUY_STOP': mt5.ORDER_TYPE_BUY_STOP,
        'SELL_STOP': mt5.ORDER_TYPE_SELL_STOP,
        'BUY_STOP_LIMIT': mt5.ORDER_TYPE_BUY_STOP_LIMIT,
        'SELL_STOP_LIMIT': mt5.ORDER_TYPE_SELL_STOP_LIMIT,
    }

    # Position types
    POSITION_TYPES = {
        'BUY': mt5.POSITION_TYPE_BUY,
        'SELL': mt5.POSITION_TYPE_SELL
    }

    # Order filling policies
    ORDER_FILLING = {
        'IOC': mt5.ORDER_FILLING_IOC,
        'FOK': mt5.ORDER_FILLING_FOK,
        'RETURN': mt5.ORDER_FILLING_RETURN
    }

    # Order time policies
    ORDER_TIME = {
        'GTC': mt5.ORDER_TIME_GTC,
        'DAY': mt5.ORDER_TIME_DAY,
        'SPECIFIED': mt5.ORDER_TIME_SPECIFIED,
        'SPECIFIED_DAY': mt5.ORDER_TIME_SPECIFIED_DAY
    }

    # Trade actions
    TRADE_ACTIONS = {
        'DEAL': mt5.TRADE_ACTION_DEAL,
        'PENDING': mt5.TRADE_ACTION_PENDING,
        'SLTP': mt5.TRADE_ACTION_SLTP,
        'MODIFY': mt5.TRADE_ACTION_MODIFY,
        'REMOVE': mt5.TRADE_ACTION_REMOVE,
    }

    def __init__(self, path: str = None, timeout: int = 60000, portable: bool = False):
        self.is_connected = False
        self.path = path
        self.timeout = timeout
        self.portable = portable
        self.account_info = None
        self.last_error_msg = None
        self.last_error_code = None

        # Normalize OS info
        platform = sys.platform
        if platform.startswith('win'):
            self._os_info = 'windows'
        elif platform.startswith('linux'):
            if os.environ.get('WINELOADERNOEXEC'):
                self._os_info = 'wine'
            else:
                self._os_info = 'linux'
        elif platform.startswith('darwin'):
            self._os_info = 'macos'
        else:
            self._os_info = 'unknown'

    def initialize(self, path: str = None, timeout: int = None, portable: bool = None) -> bool:
        """
        Initialize MT5 connection

        Args:
            path: Path to terminal executable
            timeout: Connection timeout in milliseconds
            portable: Portable mode flag

        Returns:
            bool: True if connected successfully
        """
        try:
            # Use provided parameters or defaults
            path = path or self.path
            timeout = timeout or self.timeout
            portable = portable or self.portable

            # Clean shutdown first
            mt5.shutdown()
            time.sleep(0.5)

            # Initialize with provided parameters
            if path:
                initialized = mt5.initialize(path=path, timeout=timeout, portable=portable)
            else:
                initialized = mt5.initialize()

            if not initialized:
                self.last_error_code = mt5.last_error()
                self.last_error_msg = f"Error code: {self.last_error_code}"
                print(f"❌ MT5 initialization failed: {self.last_error_msg}")
                return False

            time.sleep(1)

            # Store account info
            self.account_info = mt5.account_info()
            if self.account_info is None:
                print("⚠️ No account info retrieved (MT5 may not be logged in)")
                # Still consider connected, just not logged in
                self.is_connected = True
                return True

            self.is_connected = True
            print(f"✅ MT5 connected to {self.account_info.server} (Account: {self.account_info.login})")
            return True

        except Exception as e:
            self.last_error_msg = str(e)
            self.last_error_code = -1
            print(f"❌ Init error: {e}")
            return False

    def shutdown(self) -> None:
        """Shutdown MT5 connection"""
        try:
            mt5.shutdown()
            self.is_connected = False
            self.account_info = None
            print("✅ MT5 shutdown")
        except Exception as e:
            print(f"⚠️ Shutdown error: {e}")

    def version(self) -> Tuple[str, str, str]:
        """Get MT5 version info"""
        try:
            if not self.is_connected:
                return ("", "", "")
            version_info = mt5.version()
            if version_info:
                return (version_info[0], version_info[1], version_info[2])
            return ("", "", "")
        except:
            return ("", "", "")

    # ACCOUNT METHODS
    def get_account_info(self) -> Optional[Dict]:
        """Get detailed account information"""
        try:
            if not self.is_connected:
                return None
            info = mt5.account_info()
            if info:
                return info._asdict()
            return None
        except:
            return None

    def get_account_info_dict(self) -> Optional[Dict]:
        """Get account info as dict - alias for get_account_info"""
        return self.get_account_info()

    def get_account_balance(self) -> float:
        """Get current account balance"""
        info = self.get_account_info()
        return info.get('balance', 0.0) if info else 0.0

    def get_balance(self) -> float:
        """Get account balance - alias for get_account_balance"""
        return self.get_account_balance()

    def get_account_equity(self) -> float:
        """Get current account equity"""
        info = self.get_account_info()
        return info.get('equity', 0.0) if info else 0.0

    def get_equity(self) -> float:
        """Get account equity - alias for get_account_equity"""
        return self.get_account_equity()

    def get_account_margin(self) -> float:
        """Get current account margin"""
        info = self.get_account_info()
        return info.get('margin', 0.0) if info else 0.0

    def get_margin(self) -> float:
        """Get account margin - alias for get_account_margin"""
        return self.get_account_margin()

    def get_free_margin(self) -> float:
        """Get free margin"""
        info = self.get_account_info()
        return info.get('margin_free', 0.0) if info else 0.0

    def get_margin_level(self) -> float:
        """Get margin level percentage"""
        info = self.get_account_info()
        return info.get('margin_level', 0.0) if info else 0.0

    def get_leverage(self) -> int:
        """Get account leverage"""
        info = self.get_account_info()
        return info.get('leverage', 0) if info else 0

    # SERVER METHODS
    def get_server_info(self) -> Optional[Dict]:
        """Get server information"""
        return self.terminal_info()

    def get_server_time(self) -> Optional[datetime]:
        """Get server time"""
        try:
            if not self.is_connected:
                return None
            # Try to get time from a commonly traded symbol
            common_symbols = ['EURUSD', 'XAUUSD', 'BTCUSD']
            for symbol in common_symbols:
                tick = mt5.symbol_info_tick(symbol)
                if tick and tick.time > 0:
                    return datetime.fromtimestamp(tick.time)
            return None
        except:
            return None

    # SYMBOL METHODS
    def _clean_symbol_list(self, symbols):
        """Clean and validate symbols without filtering out extensions."""
        if not symbols:
            return []

        cleaned_symbols = []
        for symbol in symbols:
            if not symbol:
                continue
            symbol_clean = str(symbol).strip()
            if not (1 <= len(symbol_clean) <= 30):
                continue
            if symbol_clean.startswith('#'):
                continue
            cleaned_symbols.append(symbol_clean)

        return sorted(list(set(cleaned_symbols)))

    def get_market_watch_symbols(self) -> List[str]:
        """Get symbols visible in Market Watch"""
        try:
            if not self.is_connected:
                return []
            symbols = mt5.symbols_get()
            if symbols is None:
                return []
            raw_symbols = [s.name for s in symbols if s.visible]
            return self._clean_symbol_list(raw_symbols)
        except:
            return []

    def get_all_symbols(self) -> List[str]:
        """Get all available symbols"""
        try:
            if not self.is_connected:
                return []
            symbols = mt5.symbols_get()
            if symbols is None:
                return []
            raw_symbols = [s.name for s in symbols]
            return self._clean_symbol_list(raw_symbols)
        except Exception as e:
            print(f"❌ Error getting all symbols: {e}")
            return []

    def get_available_symbols(self) -> List[str]:
        """Get symbols that are available for trading"""
        all_symbols = self.get_all_symbols()
        available = []
        for symbol in all_symbols:
            info = self.get_symbol_info(symbol)
            if info and info.get('trade_mode', 0) > 0:
                available.append(symbol)
        return available

    def get_symbol_info(self, symbol: str) -> Optional[Dict]:
        """Get detailed symbol information"""
        try:
            if not self.is_connected:
                return None
            info = mt5.symbol_info(symbol)
            if info:
                return info._asdict()
            return None
        except Exception as e:
            print(f"❌ Error getting symbol info for {symbol}: {e}")
            return None

    def get_symbol_info_tick(self, symbol: str) -> Optional[Dict]:
        """Get current tick data for symbol"""
        try:
            if not self.is_connected:
                return None
            if not mt5.symbol_select(symbol, True):
                return None
            tick = mt5.symbol_info_tick(symbol)
            if tick:
                return tick._asdict()
            return None
        except Exception as e:
            print(f"❌ Error getting tick for {symbol}: {e}")
            return None

    def get_current_price(self, symbol: str) -> Dict[str, Any]:
        """Bridge-compatible live tick - uses existing get_symbol_info_tick"""
        return self.get_symbol_info_tick(symbol) or {}

    def get_symbol_price(self, symbol: str, bid_ask: str = 'bid') -> Optional[float]:
        """Get current price (bid or ask)"""
        try:
            tick = self.get_current_price(symbol)
            if not tick:
                return None
            return tick.get('bid' if bid_ask.lower() == 'bid' else 'ask')
        except:
            return None

    def symbol_select(self, symbol: str, select: bool = True) -> bool:
        """Select or deselect symbol in Market Watch"""
        try:
            if not self.is_connected:
                return False
            return mt5.symbol_select(symbol, select)
        except:
            return False

    def get_symbols_total(self) -> int:
        """Get total number of symbols"""
        try:
            if not self.is_connected:
                return 0
            return mt5.symbols_total()
        except:
            return 0

    def get_symbol_properties(self, symbol: str) -> Optional[Dict]:
        """Get all symbol properties as dictionary"""
        info = self.get_symbol_info(symbol)
        if not info:
            return None

        properties = {
            'name': info.get('name'),
            'currency_base': info.get('currency_base'),
            'currency_profit': info.get('currency_profit'),
            'currency_margin': info.get('currency_margin'),
            'digits': info.get('digits'),
            'point': info.get('point'),
            'trade_mode': info.get('trade_mode'),
            'spread': info.get('spread'),
            'spread_float': info.get('spread_float'),
            'trade_contract_size': info.get('trade_contract_size'),
            'volume_min': info.get('volume_min'),
            'volume_max': info.get('volume_max'),
            'volume_step': info.get('volume_step'),
            'swap_long': info.get('swap_long'),
            'swap_short': info.get('swap_short'),
            'bid': info.get('bid'),
            'ask': info.get('ask'),
            'time': datetime.fromtimestamp(info.get('time')) if info.get('time') else None,
            'time_msc': info.get('time_msc'),
        }
        return properties

    def get_symbol_lot_size(self, symbol: str) -> float:
        """Get standard lot size for symbol"""
        info = self.get_symbol_info(symbol)
        if info:
            return info.get('volume_step', 0.01)
        return 0.01

    def get_spread(self, symbol: str) -> float:
        """Get current spread in points"""
        try:
            tick = self.get_current_price(symbol)
            if not tick:
                return 0.0
            symbol_info = self.get_symbol_info(symbol)
            if not symbol_info or symbol_info.get('point', 0) == 0:
                return 0.0
            return (tick.get('ask', 0) - tick.get('bid', 0)) / symbol_info.get('point', 0.00001)
        except:
            return 0.0

    def is_market_open(self, symbol: str) -> bool:
        """Check if market is open for symbol"""
        try:
            info = self.get_symbol_info(symbol)
            if not info:
                return False
            return info.get('trade_mode', 0) > 0
        except:
            return False

    # MARKET DATA METHODS
    def get_rates(self, symbol: str, timeframe: str, count: int) -> Optional[List[Dict]]:
        """Get historical rates"""
        try:
            if not self.is_connected:
                return None
            tf = self.TIMEFRAMES.get(timeframe.upper(), mt5.TIMEFRAME_D1)
            if not mt5.symbol_select(symbol, True):
                return None
            rates = mt5.copy_rates_from_pos(symbol, tf, 0, count)
            if rates is None:
                return None
            return [{
                'time': datetime.fromtimestamp(r[0]),
                'open': float(r[1]), 'high': float(r[2]),
                'low': float(r[3]), 'close': float(r[4]),
                'tick_volume': float(r[5]),
                'spread': float(r[6]),
                'real_volume': float(r[7])
            } for r in rates]
        except Exception as e:
            print(f"❌ Error getting rates: {e}")
            return None

    def get_rates_from_pos(self, symbol: str, timeframe: str, start_pos: int, count: int) -> Optional[List[Dict]]:
        """Get historical rates starting from a bar position"""
        try:
            if not self.is_connected:
                return None

            tf = self.TIMEFRAMES.get(timeframe.upper(), mt5.TIMEFRAME_D1)

            if not mt5.symbol_select(symbol, True):
                print(f"❌ Symbol {symbol} not available")
                return None

            rates = mt5.copy_rates_from_pos(symbol, tf, start_pos, count)

            if rates is None:
                error_code = mt5.last_error()
                print(f"❌ Error getting rates from position: code {error_code}")
                return None

            result = []
            for r in rates:
                rate_dict = {
                    'time': datetime.fromtimestamp(r[0]),
                    'open': float(r[1]),
                    'high': float(r[2]),
                    'low': float(r[3]),
                    'close': float(r[4]),
                    'tick_volume': float(r[5]),
                    'spread': float(r[6]),
                    'real_volume': float(r[7])
                }
                result.append(rate_dict)

            return result
        except Exception as e:
            print(f"❌ Exception in get_rates_from_pos: {e}")
            return None

    def get_rates_time(self, symbol: str, timeframe: str, start_date: datetime = None, end_date: datetime = None) -> Optional[List[Dict]]:
        """Get rates for symbol by date range"""
        try:
            if not self.is_connected:
                return None
            tf = self.TIMEFRAMES.get(timeframe.upper(), mt5.TIMEFRAME_D1)
            if not mt5.symbol_select(symbol, True):
                return None

            if start_date and end_date:
                rates = mt5.copy_rates_range(symbol, tf, start_date, end_date)
            elif start_date:
                rates = mt5.copy_rates_from(symbol, tf, start_date, 1000)
            else:
                rates = mt5.copy_rates_from_pos(symbol, tf, 0, 100)

            if rates is None:
                return None

            result = []
            for r in rates:
                rate_dict = {
                    'time': datetime.fromtimestamp(r[0]),
                    'open': float(r[1]),
                    'high': float(r[2]),
                    'low': float(r[3]),
                    'close': float(r[4]),
                    'tick_volume': float(r[5]),
                    'spread': float(r[6]),
                    'real_volume': float(r[7])
                }
                result.append(rate_dict)
            return result
        except Exception as e:
            print(f"❌ Error copying rates range: {e}")
            return None

    def get_rates_from(self, symbol: str, timeframe: str,
                       date_from: datetime, count: int) -> Optional[List[Dict]]:
        """Copy rates from specified date"""
        try:
            if not self.is_connected:
                return None
            tf = self.TIMEFRAMES.get(timeframe.upper(), mt5.TIMEFRAME_D1)
            if not mt5.symbol_select(symbol, True):
                return None
            rates = mt5.copy_rates_from(symbol, tf, date_from, count)
            if rates is None:
                return None

            result = []
            for r in rates:
                rate_dict = {
                    'time': datetime.fromtimestamp(r[0]),
                    'open': float(r[1]),
                    'high': float(r[2]),
                    'low': float(r[3]),
                    'close': float(r[4]),
                    'tick_volume': float(r[5]),
                    'spread': float(r[6]),
                    'real_volume': float(r[7])
                }
                result.append(rate_dict)
            return result
        except Exception as e:
            print(f"❌ Error copying rates from: {e}")
            return None

    def get_rates_range(self, symbol: str, timeframe: str,
                        date_from: datetime, date_to: datetime) -> Optional[List[Dict]]:
        """Copy rates within date range"""
        try:
            if not self.is_connected:
                return None
            tf = self.TIMEFRAMES.get(timeframe.upper(), mt5.TIMEFRAME_D1)
            if not mt5.symbol_select(symbol, True):
                return None
            rates = mt5.copy_rates_range(symbol, tf, date_from, date_to)
            if rates is None:
                return None

            result = []
            for r in rates:
                rate_dict = {
                    'time': datetime.fromtimestamp(r[0]),
                    'open': float(r[1]),
                    'high': float(r[2]),
                    'low': float(r[3]),
                    'close': float(r[4]),
                    'tick_volume': float(r[5]),
                    'spread': float(r[6]),
                    'real_volume': float(r[7])
                }
                result.append(rate_dict)
            return result
        except Exception as e:
            print(f"❌ Error copying rates range: {e}")
            return None

    def get_timeframe_rates(self, symbol: str, timeframe: str, count: int) -> Optional[List[Dict]]:
        """Get rates for specific timeframe - alias for get_rates"""
        return self.get_rates(symbol, timeframe, count)

    def get_ticks_from(self, symbol: str, date_from: datetime, count: int,
                       flags: int = mt5.COPY_TICKS_ALL) -> Optional[List[Dict]]:
        """Copy ticks from specified date"""
        try:
            if not self.is_connected:
                return None
            if not mt5.symbol_select(symbol, True):
                return None
            ticks = mt5.copy_ticks_from(symbol, date_from, count, flags)
            if ticks is None:
                return None

            result = []
            for t in ticks:
                tick_dict = {
                    'time': datetime.fromtimestamp(t[0] / 1000),
                    'bid': float(t[1]),
                    'ask': float(t[2]),
                    'last': float(t[3]),
                    'volume': float(t[4]),
                    'flags': int(t[5])
                }
                result.append(tick_dict)
            return result
        except Exception as e:
            print(f"❌ Error copying ticks from: {e}")
            return None

    def get_ticks_range(self, symbol: str, date_from: datetime, date_to: datetime,
                        flags: int = mt5.COPY_TICKS_ALL) -> Optional[List[Dict]]:
        """Copy ticks within date range"""
        try:
            if not self.is_connected:
                return None
            if not mt5.symbol_select(symbol, True):
                return None
            ticks = mt5.copy_ticks_range(symbol, date_from, date_to, flags)
            if ticks is None:
                return None

            result = []
            for t in ticks:
                tick_dict = {
                    'time': datetime.fromtimestamp(t[0] / 1000),
                    'bid': float(t[1]),
                    'ask': float(t[2]),
                    'last': float(t[3]),
                    'volume': float(t[4]),
                    'flags': int(t[5])
                }
                result.append(tick_dict)
            return result
        except Exception as e:
            print(f"❌ Error copying ticks range: {e}")
            return None

    def get_timeframes(self) -> Dict[str, str]:
        """Get available timeframes"""
        return {
            'M5': 'M5',
            'M15': 'M15',
            'H1': 'H1',
            'H4': 'H4',
            'D1': 'D1',
            'W1': 'W1',
        }

    def verify_symbol_timeframe(self, symbol: str, timeframe: str) -> dict:
        """Verify if symbol/timeframe combination is valid"""
        try:
            if not self.is_connected:
                return {"valid": False, "error": "Not connected", "bars": 0}

            rates = self.get_rates(symbol, timeframe, 1)
            if rates and len(rates) > 0:
                return {"valid": True, "error": "", "bars": 1}
            else:
                return {"valid": False, "error": "No data available", "bars": 0}
        except Exception as e:
            return {"valid": False, "error": str(e), "bars": 0}

    # TRADING METHODS
    def place_order(self, symbol: str, order_type: str, volume: float,
                   price: float = 0.0, sl: float = 0.0, tp: float = 0.0,
                   deviation: int = 10, magic: int = 0,
                   comment: str = "", expiration: datetime = None,
                   fill_type: str = 'IOC', time_type: str = 'GTC') -> dict:
        """
        Place a new order (market or pending)

        Returns:
            dict with status, message, and order_ticket
        """
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected"}

            # Select symbol
            if not mt5.symbol_select(symbol, True):
                return {"status": "error", "message": f"Symbol {symbol} not available"}

            # Get symbol info
            symbol_info = mt5.symbol_info(symbol)
            if symbol_info is None:
                return {"status": "error", "message": f"Cannot get symbol info for {symbol}"}

            # Get current tick for market orders
            if order_type in ['BUY', 'SELL']:
                tick = mt5.symbol_info_tick(symbol)
                if tick is None:
                    return {"status": "error", "message": f"Cannot get tick for {symbol}"}

            # Determine action type
            if order_type in ['BUY', 'SELL']:
                action = mt5.TRADE_ACTION_DEAL
                if order_type == 'BUY':
                    order_type_mt5 = mt5.ORDER_TYPE_BUY
                    price = price or tick.ask
                else:  # SELL
                    order_type_mt5 = mt5.ORDER_TYPE_SELL
                    price = price or tick.bid
            else:
                action = mt5.TRADE_ACTION_PENDING
                order_type_mt5 = self.ORDER_TYPES.get(order_type, mt5.ORDER_TYPE_BUY_LIMIT)
                if price == 0:
                    return {"status": "error", "message": "Price must be specified for pending orders"}

            # Prepare request
            request = {
                "action": action,
                "symbol": symbol,
                "volume": float(volume),
                "type": order_type_mt5,
                "price": float(price),
                "sl": float(sl),
                "tp": float(tp),
                "deviation": deviation,
                "magic": magic,
                "comment": comment,
                "type_filling": self.ORDER_FILLING.get(fill_type, mt5.ORDER_FILLING_IOC),
                "type_time": self.ORDER_TIME.get(time_type, mt5.ORDER_TIME_GTC),
            }

            # Add expiration if specified
            if expiration:
                request["expiration"] = int(expiration.timestamp())

            # Send order
            result = mt5.order_send(request)

            if result is None:
                return {"status": "error", "message": "Order send failed (no result)"}

            if result.retcode != mt5.TRADE_RETCODE_DONE:
                return {"status": "error", "message": f"Order failed: code {result.retcode}"}

            return {"status": "success", "message": f"Order #{result.order} placed", "order": result.order}

        except Exception as e:
            return {"status": "error", "message": f"Exception placing order: {str(e)}"}

    def send_trade(self, action_type: str, symbol: str, lot_size: float,
                   stop_loss: float = 0.0, take_profit: float = 0.0) -> Tuple[bool, str]:
        """Send a market trade (simplified version of place_order)"""
        result = self.place_order(
            symbol=symbol,
            order_type=action_type,
            volume=lot_size,
            sl=stop_loss,
            tp=take_profit
        )
        return result.get("status") == "success", result.get("message", "")

    def modify_order(self, order_ticket: int, price: float = None,
                    sl: float = None, tp: float = None,
                    expiration: datetime = None) -> dict:
        """Modify an existing pending order"""
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected"}

            # Get order
            orders = mt5.orders_get(ticket=order_ticket)
            if not orders:
                return {"status": "error", "message": f"Order #{order_ticket} not found"}

            order = orders[0]

            # Prepare modification request
            request = {
                "action": mt5.TRADE_ACTION_MODIFY,
                "order": order_ticket,
                "price": float(price) if price is not None else order.price_open,
                "sl": float(sl) if sl is not None else order.sl,
                "tp": float(tp) if tp is not None else order.tp,
                "type_time": order.type_time,
                "expiration": int(expiration.timestamp()) if expiration else 0
            }

            # Send modification
            result = mt5.order_send(request)

            if result is None:
                return {"status": "error", "message": "Modify order failed (no result)"}

            if result.retcode != mt5.TRADE_RETCODE_DONE:
                return {"status": "error", "message": f"Modify failed: code {result.retcode}"}

            return {"status": "success", "message": f"Order #{order_ticket} modified"}

        except Exception as e:
            return {"status": "error", "message": f"Exception modifying order: {str(e)}"}

    def delete_order(self, order_ticket: int) -> dict:
        """Delete a pending order"""
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected"}

            request = {
                "action": mt5.TRADE_ACTION_REMOVE,
                "order": order_ticket
            }

            result = mt5.order_send(request)

            if result is None:
                return {"status": "error", "message": "Delete order failed (no result)"}

            if result.retcode != mt5.TRADE_RETCODE_DONE:
                return {"status": "error", "message": f"Delete failed: code {result.retcode}"}

            return {"status": "success", "message": f"Order #{order_ticket} deleted"}

        except Exception as e:
            return {"status": "error", "message": f"Exception deleting order: {str(e)}"}

    def close_position(self, ticket: int, deviation: int = 10) -> dict:
        """Close a specific position"""
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected"}

            # Get position
            positions = mt5.positions_get(ticket=ticket)
            if not positions:
                return {"status": "error", "message": f"Position #{ticket} not found"}

            position = positions[0]

            # Get current tick
            tick = mt5.symbol_info_tick(position.symbol)
            if tick is None:
                return {"status": "error", "message": f"Cannot get tick for {position.symbol}"}

            # Determine opposite action
            if position.type == mt5.POSITION_TYPE_BUY:
                close_type = mt5.ORDER_TYPE_SELL
                price = tick.bid
            else:
                close_type = mt5.ORDER_TYPE_BUY
                price = tick.ask

            # Prepare close request
            request = {
                "action": mt5.TRADE_ACTION_DEAL,
                "symbol": position.symbol,
                "volume": position.volume,
                "type": close_type,
                "position": position.ticket,
                "price": price,
                "deviation": deviation,
                "magic": position.magic,
                "comment": f"Close position #{ticket}",
                "type_time": mt5.ORDER_TIME_GTC,
                "type_filling": mt5.ORDER_FILLING_IOC,
            }

            # Send close order
            result = mt5.order_send(request)

            if result is None:
                return {"status": "error", "message": "Close order failed (no result)"}

            if result.retcode != mt5.TRADE_RETCODE_DONE:
                return {"status": "error", "message": f"Close failed: code {result.retcode}"}

            return {"status": "success", "message": f"Position #{ticket} closed at {result.price}"}

        except Exception as e:
            return {"status": "error", "message": f"Exception closing position: {str(e)}"}

    def close_symbol_positions(self, symbol: str) -> dict:
        """Close all positions for a specific symbol"""
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected"}

            positions = mt5.positions_get(symbol=symbol)
            if not positions:
                return {"status": "success", "message": f"No positions for {symbol}"}

            closed_count = 0
            errors = []

            for position in positions:
                result = self.close_position(position.ticket)
                if result.get("status") == "success":
                    closed_count += 1
                else:
                    errors.append(f"#{position.ticket}: {result.get('message')}")

            if errors:
                return {"status": "error", "message": f"Closed {closed_count}/{len(positions)}. Errors: {'; '.join(errors)}"}

            return {"status": "success", "message": f"Closed {closed_count} positions for {symbol}"}

        except Exception as e:
            return {"status": "error", "message": f"Exception closing {symbol} positions: {str(e)}"}

    def close_all_positions(self) -> dict:
        """Close all open positions"""
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected"}

            positions = mt5.positions_get()
            if not positions:
                return {"status": "success", "message": "No positions to close"}

            closed_count = 0
            errors = []

            for position in positions:
                result = self.close_position(position.ticket)
                if result.get("status") == "success":
                    closed_count += 1
                else:
                    errors.append(f"#{position.ticket}: {result.get('message')}")

            if errors:
                return {"status": "error", "message": f"Closed {closed_count}/{len(positions)}. Errors: {'; '.join(errors)}"}

            return {"status": "success", "message": f"Closed {closed_count} positions"}

        except Exception as e:
            return {"status": "error", "message": f"Exception closing all positions: {str(e)}"}

    def close_position_by_symbol(self, symbol: str, volume: float = None) -> Tuple[bool, str]:
        """Close all positions for a symbol (legacy method)"""
        result = self.close_symbol_positions(symbol)
        return result.get("status") == "success", result.get("message", "")

    def modify_position(self, ticket: int, sl: float = None, tp: float = None) -> dict:
        """Modify position SL/TP"""
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected"}

            positions = mt5.positions_get(ticket=ticket)
            if not positions:
                return {"status": "error", "message": f"Position #{ticket} not found"}

            position = positions[0]

            sl = float(sl) if sl is not None else position.sl
            tp = float(tp) if tp is not None else position.tp

            request = {
                "action": mt5.TRADE_ACTION_SLTP,
                "symbol": position.symbol,
                "sl": sl,
                "tp": tp,
                "position": position.ticket
            }

            result = mt5.order_send(request)

            if result is None:
                return {"status": "error", "message": "Modify position failed (no result)"}

            if result.retcode != mt5.TRADE_RETCODE_DONE:
                return {"status": "error", "message": f"Modify failed: code {result.retcode}"}

            return {"status": "success", "message": f"Position #{ticket} modified (SL: {sl}, TP: {tp})"}

        except Exception as e:
            return {"status": "error", "message": f"Exception modifying position: {str(e)}"}

    def calculate_position_size(self, symbol: str, risk_percent: float, stop_loss_pips: float) -> dict:
        """Calculate position size based on risk percentage"""
        try:
            if not self.is_connected:
                return {"status": "error", "message": "MT5 not connected", "volume": 0.0}

            account_info = self.get_account_info()
            if not account_info:
                return {"status": "error", "message": "Cannot get account info", "volume": 0.0}

            symbol_info = self.get_symbol_info(symbol)
            if not symbol_info:
                return {"status": "error", "message": f"Cannot get symbol info for {symbol}", "volume": 0.0}

            balance = account_info.get('balance', 0)
            risk_amount = balance * (risk_percent / 100)

            tick_value = symbol_info.get('trade_tick_value', 0)
            if tick_value == 0:
                return {"status": "error", "message": "Cannot determine tick value", "volume": 0.0}

            volume = risk_amount / (stop_loss_pips * tick_value)

            volume_step = symbol_info.get('volume_step', 0.01)
            volume = round(volume / volume_step) * volume_step

            volume_min = symbol_info.get('volume_min', 0.01)
            volume_max = symbol_info.get('volume_max', 100)
            volume = max(volume_min, min(volume, volume_max))

            return {
                "status": "success",
                "message": f"Calculated volume: {volume}",
                "volume": volume,
                "risk_amount": risk_amount,
                "balance": balance,
                "risk_percent": risk_percent,
                "stop_loss_pips": stop_loss_pips
            }

        except Exception as e:
            return {"status": "error", "message": f"Exception calculating position size: {str(e)}", "volume": 0.0}

    # ORDER & POSITION QUERY METHODS
    def get_positions(self, symbol: str = "") -> List[Dict]:
        """Get open positions"""
        try:
            if not self.is_connected:
                return []

            if symbol:
                positions = mt5.positions_get(symbol=symbol)
            else:
                positions = mt5.positions_get()

            if positions is None:
                return []

            return [p._asdict() for p in positions]
        except Exception as e:
            print(f"❌ Error getting positions: {e}")
            return []

    def get_orders(self, symbol: str = "") -> List[Dict]:
        """Get pending orders"""
        try:
            if not self.is_connected:
                return []

            if symbol:
                orders = mt5.orders_get(symbol=symbol)
            else:
                orders = mt5.orders_get()

            if orders is None:
                return []

            return [o._asdict() for o in orders]
        except Exception as e:
            print(f"❌ Error getting orders: {e}")
            return []

    def get_positions_total(self) -> int:
        """Get total number of open positions"""
        try:
            if not self.is_connected:
                return 0
            return mt5.positions_total()
        except:
            return 0

    def get_orders_total(self) -> int:
        """Get total number of pending orders"""
        try:
            if not self.is_connected:
                return 0
            return mt5.orders_total()
        except:
            return 0

    def get_position_tickets(self, symbol: str = "") -> List[int]:
        """Get list of position tickets"""
        positions = self.get_positions(symbol=symbol)
        return [p['ticket'] for p in positions]

    def get_order_tickets(self, symbol: str = "") -> List[int]:
        """Get list of order tickets"""
        orders = self.get_orders(symbol=symbol)
        return [o['ticket'] for o in orders]

    def get_position_by_symbol(self, symbol: str) -> Optional[Dict]:
        """Get first position for a symbol"""
        positions = self.get_positions(symbol=symbol)
        return positions[0] if positions else None

    def get_order_by_symbol(self, symbol: str) -> Optional[Dict]:
        """Get first order for a symbol"""
        orders = self.get_orders(symbol=symbol)
        return orders[0] if orders else None

    def get_total_profit(self) -> float:
        """Get total profit from all open positions"""
        positions = self.get_positions()
        return sum(p.get('profit', 0) for p in positions)

    # HISTORY METHODS
    def get_history_orders(self, date_from: datetime = None, date_to: datetime = None,
                          group: str = "", ticket: int = 0) -> List[Dict]:
        """Get history orders"""
        try:
            if not self.is_connected:
                return []

            if ticket > 0:
                orders = mt5.history_orders_get(ticket=ticket)
            elif date_from and date_to:
                orders = mt5.history_orders_get(date_from, date_to)
            elif group:
                orders = mt5.history_orders_get(group=group)
            else:
                orders = mt5.history_orders_get()

            if orders is None:
                return []

            return [o._asdict() for o in orders]
        except Exception as e:
            print(f"❌ Error getting history orders: {e}")
            return []

    def get_history_deals(self, date_from: datetime = None, date_to: datetime = None,
                         group: str = "", ticket: int = 0) -> List[Dict]:
        """Get history deals"""
        try:
            if not self.is_connected:
                return []

            if ticket > 0:
                deals = mt5.history_deals_get(ticket=ticket)
            elif date_from and date_to:
                deals = mt5.history_deals_get(date_from, date_to)
            elif group:
                deals = mt5.history_deals_get(group=group)
            else:
                deals = mt5.history_deals_get()

            if deals is None:
                return []

            return [d._asdict() for d in deals]
        except Exception as e:
            print(f"❌ Error getting history deals: {e}")
            return []

    def get_history_orders_total(self, date_from: datetime, date_to: datetime) -> int:
        """Get total number of history orders in date range"""
        try:
            if not self.is_connected:
                return 0
            return mt5.history_orders_total(date_from, date_to)
        except:
            return 0

    def get_history_deals_total(self, date_from: datetime, date_to: datetime) -> int:
        """Get total number of history deals in date range"""
        try:
            if not self.is_connected:
                return 0
            return mt5.history_deals_total(date_from, date_to)
        except:
            return 0

    # UTILITY METHODS
    def terminal_info(self) -> Optional[Dict]:
        """Get terminal information"""
        try:
            if not self.is_connected:
                return None
            info = mt5.terminal_info()
            if info:
                return info._asdict()
            return None
        except:
            return None

    def get_last_error(self) -> Tuple[int, str]:
        """Get last error code and description"""
        try:
            self.last_error_code = mt5.last_error()
            self.last_error_msg = f"Error code: {self.last_error_code}"
            return self.last_error_code, self.last_error_msg
        except:
            self.last_error_code = -1
            self.last_error_msg = "Unknown error"
            return self.last_error_code, self.last_error_msg

    def check_order_conditions(self, symbol: str, order_type: str,
                              volume: float, price: float = 0.0) -> Tuple[bool, str]:
        """Check if order conditions are valid"""
        try:
            if not self.is_connected:
                return False, "MT5 not connected"

            symbol_info = self.get_symbol_info(symbol)
            if not symbol_info:
                return False, f"Symbol {symbol} not found"

            if volume < symbol_info.get('volume_min', 0.01):
                return False, f"Volume too small (min: {symbol_info.get('volume_min', 0.01)})"
            if volume > symbol_info.get('volume_max', 100):
                return False, f"Volume too large (max: {symbol_info.get('volume_max', 100)})"

            if not symbol_info.get('trade_mode', False):
                return False, f"Symbol {symbol} is not tradeable"

            if order_type not in ['BUY', 'SELL'] and price == 0:
                return False, "Price must be specified for pending orders"

            return True, "Order conditions OK"

        except Exception as e:
            return False, f"Error checking conditions: {str(e)}"

    def calculate_margin(self, symbol: str, order_type: str,
                        volume: float, price: float = 0.0) -> float:
        """Calculate required margin for an order"""
        try:
            if not self.is_connected:
                return 0.0

            if price == 0:
                tick = self.get_current_price(symbol)
                if not tick:
                    return 0.0
                price = tick.get('ask') if order_type in ['BUY', 'BUY_LIMIT', 'BUY_STOP'] else tick.get('bid')

            order_type_mt5 = self.ORDER_TYPES.get(order_type, mt5.ORDER_TYPE_BUY)
            margin = mt5.order_calc_margin(
                order_type_mt5,
                symbol,
                volume,
                price
            )
            return margin if margin is not None else 0.0
        except Exception as e:
            print(f"❌ Error calculating margin: {e}")
            return 0.0

    def calculate_profit(self, symbol: str, order_type: str,
                        volume: float, open_price: float, close_price: float) -> float:
        """Calculate potential profit/loss"""
        try:
            if not self.is_connected:
                return 0.0

            order_type_mt5 = self.ORDER_TYPES.get(order_type, mt5.ORDER_TYPE_BUY)
            profit = mt5.order_calc_profit(
                order_type_mt5,
                symbol,
                volume,
                open_price,
                close_price
            )
            return profit if profit is not None else 0.0
        except Exception as e:
            print(f"❌ Error calculating profit: {e}")
            return 0.0

    # BATCH OPERATIONS
    def send_batch_orders(self, orders: List[Dict]) -> List[dict]:
        """Send multiple orders in batch"""
        results = []
        for order in orders:
            result = self.place_order(**order)
            results.append(result)
            time.sleep(0.1)
        return results

    def close_multiple_positions(self, tickets: List[int]) -> List[dict]:
        """Close multiple positions"""
        results = []
        for ticket in tickets:
            result = self.close_position(ticket)
            results.append(result)
            time.sleep(0.1)
        return results

    # STATUS & MONITORING
    def get_trading_status(self) -> Dict[str, Any]:
        """Get comprehensive trading status"""
        status = {
            'connected': self.is_connected,
            'account': self.get_account_info(),
            'terminal': self.terminal_info(),
            'positions_total': self.get_positions_total(),
            'orders_total': self.get_orders_total(),
            'balance': self.get_account_balance(),
            'equity': self.get_account_equity(),
            'margin': self.get_account_margin(),
            'free_margin': self.get_free_margin(),
            'margin_level': self.get_margin_level(),
            'timestamp': datetime.now().isoformat()
        }
        return status

    def monitor_positions(self, callback: callable, interval: int = 5) -> None:
        """Monitor positions with callback"""
        import threading
        def monitor():
            last_count = 0
            while self.is_connected:
                current_count = self.get_positions_total()
                if current_count != last_count:
                    positions = self.get_positions()
                    callback(positions, current_count)
                    last_count = current_count
                time.sleep(interval)

        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()

    # EXPORT/IMPORT
    def export_positions_to_csv(self, filename: str) -> bool:
        """Export positions to CSV file"""
        try:
            positions = self.get_positions()
            if not positions:
                return False

            df = pd.DataFrame(positions)
            df.to_csv(filename, index=False)
            print(f"✅ Exported {len(positions)} positions to {filename}")
            return True
        except Exception as e:
            print(f"❌ Error exporting positions: {e}")
            return False

    def export_orders_to_csv(self, filename: str) -> bool:
        """Export orders to CSV file"""
        try:
            orders = self.get_orders()
            if not orders:
                return False

            df = pd.DataFrame(orders)
            df.to_csv(filename, index=False)
            print(f"✅ Exported {len(orders)} orders to {filename}")
            return True
        except Exception as e:
            print(f"❌ Error exporting orders: {e}")
            return False

    def export_history_to_csv(self, filename: str, days: int = 7) -> bool:
        """Export trading history to CSV"""
        try:
            date_from = datetime.now() - timedelta(days=days)
            date_to = datetime.now()

            deals = self.get_history_deals(date_from, date_to)
            orders = self.get_history_orders(date_from, date_to)

            if not deals and not orders:
                return False

            all_data = []
            for deal in deals:
                deal['type'] = 'deal'
                all_data.append(deal)
            for order in orders:
                order['type'] = 'order'
                all_data.append(order)

            df = pd.DataFrame(all_data)
            df.to_csv(filename, index=False)
            print(f"✅ Exported {len(all_data)} history items to {filename}")
            return True
        except Exception as e:
            print(f"❌ Error exporting history: {e}")
            return False

    # CONNECTION TESTING METHODS
    def ping(self) -> dict:
        """Ping to check connection"""
        if not self.is_connected:
            return {"status": "error", "message": "Not connected"}
        return {"status": "success", "message": "pong"}

    def test_connection(self) -> dict:
        """Test connection"""
        if not self.is_connected:
            return {"status": "error", "message": "Not connected"}
        return {"status": "success", "message": "Connection OK"}

    def heartbeat(self) -> dict:
        """Heartbeat to keep connection alive"""
        if not self.is_connected:
            return {"status": "error", "message": "Not connected"}
        return {"status": "success", "message": "alive"}

    # DISCOVERY METHODS
    def get_available_methods(self) -> dict:
        """Get available methods"""
        methods = [
            'initialize', 'shutdown', 'version',
            'get_account_info', 'get_account_info_dict', 'get_account_balance', 'get_balance',
            'get_account_equity', 'get_equity', 'get_account_margin', 'get_margin',
            'get_free_margin', 'get_margin_level', 'get_leverage',
            'get_server_info', 'get_server_time',
            'get_market_watch_symbols', 'get_all_symbols', 'get_available_symbols',
            'get_symbol_info', 'get_symbol_info_tick', 'get_current_price',
            'get_symbol_price', 'symbol_select', 'get_symbols_total',
            'get_symbol_properties', 'get_symbol_lot_size', 'get_spread',
            'is_market_open',
            'get_rates', 'get_rates_from_pos', 'get_rates_time',
            'get_rates_from', 'get_rates_range', 'get_timeframe_rates',
            'get_ticks_from', 'get_ticks_range', 'get_timeframes',
            'verify_symbol_timeframe',
            'place_order', 'send_trade', 'modify_order', 'delete_order',
            'close_position', 'close_symbol_positions', 'close_all_positions',
            'close_position_by_symbol', 'modify_position', 'calculate_position_size',
            'get_positions', 'get_orders', 'get_positions_total', 'get_orders_total',
            'get_position_tickets', 'get_order_tickets', 'get_position_by_symbol',
            'get_order_by_symbol', 'get_total_profit',
            'get_history_orders', 'get_history_deals',
            'get_history_orders_total', 'get_history_deals_total',
            'terminal_info', 'get_last_error',
            'check_order_conditions', 'calculate_margin', 'calculate_profit',
            'send_batch_orders', 'close_multiple_positions',
            'get_trading_status', 'monitor_positions',
            'export_positions_to_csv', 'export_orders_to_csv', 'export_history_to_csv',
            'ping', 'test_connection', 'heartbeat',
            'get_available_methods', 'test_method'
        ]
        return {"status": "success", "methods": methods}

    def test_method(self, method_name: str = "") -> dict:
        """Test a specific method"""
        if not self.is_connected:
            return {"status": "error", "message": "Not connected"}

        if not method_name:
            return {"status": "error", "message": "Method name required"}

        try:
            if hasattr(self, method_name):
                return {"status": "success", "message": f"Method '{method_name}' exists"}
            else:
                return {"status": "error", "message": f"Method '{method_name}' not found"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

# ==================== GUI EMBED CLASS ====================
class MT5APIEmbed:
    """
    Embeddable GUI for direct MT5 API integration using CustomTkinter.
    Replaces Mt5BridgeEmbed with direct MT5API control.
    """

    def __init__(self, parent_frame, on_connect_callback=None, on_disconnect_callback=None,
                 config_file="mt5_connector.ini"):
        """
        Initialize embed mode.

        Args:
            parent_frame: CTk frame to embed into
            on_connect_callback: Optional callback when connection is established
            on_disconnect_callback: Optional callback when disconnected
            config_file: Configuration file path
        """
        self.parent = parent_frame
        self.config_file = config_file
        self.mt5_api = None
        self.connected = False
        self.auto_connect_var = ctk.BooleanVar(value=False)
        self.data_dir = DEFAULT_DATA_DIR

        # For rate display functionality - MODIFIED for 5 updates only
        self.current_rate_symbol = None
        self.rate_update_job = None
        self.rate_update_count = 0
        self.max_rate_updates = 5
        self.rate_update_interval = 1000  # 1 second

        # Callbacks
        self.on_connect_callback = on_connect_callback
        self.on_disconnect_callback = on_disconnect_callback

        # Load config
        self.saved_state = self._load_config()

        # Create widgets
        self._create_widgets()

        # Apply saved config
        self._apply_config()

    def _create_widgets(self):
        """Create all GUI widgets using CustomTkinter with ConfigCtk styling"""

        # ==================== MT5 API FRAME ====================
        self.api_frame = ctk.CTkFrame(
            self.parent,
            fg_color=ConfigCtk.BG1,
            corner_radius=0
        )
        self.api_frame.pack(fill="x", padx=1, pady=1)

        # Row 1: Path to terminal (optional)
        self.path_frame = ctk.CTkFrame(
            self.api_frame,
            fg_color="transparent"
        )
        self.path_frame.pack(fill="x", padx=5, pady=2)

        ctk.CTkLabel(
            self.path_frame,
            text="Terminal Path:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 2))

        self.path_entry = ctk.CTkEntry(
            self.path_frame,
            width=250,
            font=("Roboto", 12),
            fg_color=ConfigCtk.BG2,
            text_color=ConfigCtk.FG,
            border_color=ConfigCtk.BG3,
            border_width=1
        )
        self.path_entry.pack(side="left", padx=(0, 5))

        self.path_browse_btn = ctk.CTkButton(
            self.path_frame,
            text="Browse",
            command=self._browse_path,
            width=70,
            font=("Roboto", 12),
            fg_color=ConfigCtk.DARK_BLUE,      # Dark blue background
            hover_color="#2e4aad",              # Lighter dark blue on hover
            text_color=ConfigCtk.FG             # Light text
        )
        self.path_browse_btn.pack(side="left")

        # Row 2: Buttons, Auto Connect, and Data Folder
        self.buttons_frame = ctk.CTkFrame(
            self.api_frame,
            fg_color="transparent"
        )
        self.buttons_frame.pack(fill="x", padx=5, pady=5)

        self.connect_btn = ctk.CTkButton(
            self.buttons_frame,
            text="Connect",
            command=self._connect_mt5,
            width=90,
            font=("Roboto", 12),
            fg_color=ConfigCtk.DARK_BLUE,      # Dark blue background
            hover_color="#2e4aad",              # Lighter dark blue on hover
            text_color=ConfigCtk.FG             # Light text
        )
        self.connect_btn.pack(side="left", padx=(0, 2))

        self.disconnect_btn = ctk.CTkButton(
            self.buttons_frame,
            text="Disconnect",
            command=self._disconnect_mt5,
            width=90,
            state="disabled",
            font=("Roboto", 12),
            fg_color=ConfigCtk.DARK_BLUE,      # Dark blue background
            hover_color="#2e4aad",              # Lighter dark blue on hover
            text_color=ConfigCtk.FG             # Light text
        )
        self.disconnect_btn.pack(side="left", padx=(0, 10))

        # Auto Connect checkbox
        self.auto_connect_cb = ctk.CTkCheckBox(
            self.buttons_frame,
            text="Auto",
            variable=self.auto_connect_var,
            command=self._on_auto_connect_change,
            font=("Roboto", 12),
            fg_color=ConfigCtk.BG2,
            border_color=ConfigCtk.BG3,
            hover_color=ConfigCtk.BG3,
            text_color=ConfigCtk.FG
        )
        self.auto_connect_cb.pack(side="left", padx=(0, 15))

        # Data Folder selector
        ctk.CTkLabel(
            self.buttons_frame,
            text="Data Folder:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 2))

        self.data_dir_label = ctk.CTkLabel(
            self.buttons_frame,
            text=os.path.basename(self.data_dir),
            fg_color=ConfigCtk.BG2,
            corner_radius=3,
            padx=5,
            pady=2,
            font=("Roboto", 12),
            text_color=ConfigCtk.FG
        )
        self.data_dir_label.pack(side="left", padx=(0, 2))

        self.data_dir_btn = ctk.CTkButton(
            self.buttons_frame,
            text="📁",
            command=self._browse_data_dir,
            width=25,
            font=("Roboto", 12),
            fg_color=ConfigCtk.DARK_BLUE,      # Dark blue background
            hover_color="#2e4aad",              # Lighter dark blue on hover
            text_color=ConfigCtk.FG             # Light text
        )
        self.data_dir_btn.pack(side="left")

        # Row 3: Market Watch Symbol dropdown
        self.symbol_frame_row = ctk.CTkFrame(
            self.api_frame,
            fg_color="transparent"
        )
        self.symbol_frame_row.pack(fill="x", padx=5, pady=2)

        ctk.CTkLabel(
            self.symbol_frame_row,
            text="MW:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 2))

        # Market Watch Symbol dropdown
        self.mw_symbol_var = ctk.StringVar()
        self.mw_symbol_combo = ctk.CTkComboBox(
            self.symbol_frame_row,
            variable=self.mw_symbol_var,
            width=120,
            state="readonly",
            values=["Select Symbol"],
            font=("Roboto", 12),
            fg_color=ConfigCtk.BG2,
            text_color=ConfigCtk.FG,
            border_color=ConfigCtk.BG3,
            button_color=ConfigCtk.ACCENT,
            button_hover_color=ConfigCtk.ACCENT2,
            dropdown_fg_color=ConfigCtk.BG1,
            dropdown_text_color=ConfigCtk.FG,
            dropdown_hover_color=ConfigCtk.BG3
        )
        self.mw_symbol_combo.pack(side="left", padx=(0, 5))
        self.mw_symbol_combo.set("Select Symbol")
        self.mw_symbol_combo.configure(command=self._on_mw_symbol_selected)

        # All Symbols dropdown
        ctk.CTkLabel(
            self.symbol_frame_row,
            text="All:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 2))

        self.all_symbols_var = ctk.StringVar()
        self.all_symbols_combo = ctk.CTkComboBox(
            self.symbol_frame_row,
            variable=self.all_symbols_var,
            width=140,
            state="readonly",
            values=["Select Symbol"],
            font=("Roboto", 12),
            fg_color=ConfigCtk.BG2,
            text_color=ConfigCtk.FG,
            border_color=ConfigCtk.BG3,
            button_color=ConfigCtk.ACCENT,
            button_hover_color=ConfigCtk.ACCENT2,
            dropdown_fg_color=ConfigCtk.BG1,
            dropdown_text_color=ConfigCtk.FG,
            dropdown_hover_color=ConfigCtk.BG3
        )
        self.all_symbols_combo.pack(side="left")
        self.all_symbols_combo.set("Select Symbol")

        # Row 4: Rate Display
        self.rate_frame = ctk.CTkFrame(
            self.api_frame,
            height=35,
            fg_color=ConfigCtk.BG2
        )
        self.rate_frame.pack(fill="x", padx=5, pady=3)

        self.rate_label = ctk.CTkLabel(
            self.rate_frame,
            text="Rate: N/A",
            font=("Courier", 12, "bold"),
            text_color=ConfigCtk.GREEN
        )
        self.rate_label.pack(fill="x", padx=5, pady=3)

        # ==================== DATA FETCHING FRAME ====================
        self.fetch_frame = ctk.CTkFrame(
            self.parent,
            fg_color=ConfigCtk.BG1,
            corner_radius=0
        )
        self.fetch_frame.pack(fill="x", padx=1, pady=1)

        # Row 1: Fetch button | Symbol dropdown | Bars entry
        row1 = ctk.CTkFrame(
            self.fetch_frame,
            fg_color="transparent"
        )
        row1.pack(fill="x", padx=5, pady=2)

        # Fetch All button
        self.fetch_btn = ctk.CTkButton(
            row1,
            text="FETCH ALL",
            command=self._fetch_all_symbols,
            width=90,
            state="disabled",
            font=("Roboto", 12),
            fg_color=ConfigCtk.DARK_BLUE,      # Dark blue background
            hover_color="#2e4aad",              # Lighter dark blue on hover
            text_color=ConfigCtk.FG             # Light text
        )
        self.fetch_btn.pack(side="left", padx=(0, 5))

        # Fetch Selection button
        self.fetch_selection_btn = ctk.CTkButton(
            row1,
            text="FETCH SELECTION",
            command=self._fetch_selected_symbol,
            width=120,
            state="disabled",
            font=("Roboto", 12),
            fg_color=ConfigCtk.DARK_BLUE,      # Dark blue background
            hover_color="#2e4aad",              # Lighter dark blue on hover
            text_color=ConfigCtk.FG             # Light text
        )
        self.fetch_selection_btn.pack(side="left", padx=(0, 5))

        ctk.CTkLabel(
            row1,
            text="Symbol:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 2))

        self.symbol_combo = ctk.CTkComboBox(
            row1,
            width=120,
            state="readonly",
            values=["Select Symbol"],
            font=("Roboto", 12),
            fg_color=ConfigCtk.BG2,
            text_color=ConfigCtk.FG,
            border_color=ConfigCtk.BG3,
            button_color=ConfigCtk.ACCENT,
            button_hover_color=ConfigCtk.ACCENT2,
            dropdown_fg_color=ConfigCtk.BG1,
            dropdown_text_color=ConfigCtk.FG,
            dropdown_hover_color=ConfigCtk.BG3
        )
        self.symbol_combo.pack(side="left", padx=(0, 5))
        self.symbol_combo.set("Select Symbol")
        self.symbol_combo.configure(command=self._on_symbol_selected)

        # Refresh button
        self.refresh_symbols_btn = ctk.CTkButton(
            row1,
            text="↻",
            command=self._refresh_symbols,
            width=25,
            state="disabled",
            font=("Roboto", 12),
            fg_color=ConfigCtk.DARK_BLUE,      # Dark blue background
            hover_color="#2e4aad",              # Lighter dark blue on hover
            text_color=ConfigCtk.FG             # Light text
        )
        self.refresh_symbols_btn.pack(side="left", padx=(0, 5))

        ctk.CTkLabel(
            row1,
            text="Bars:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 2))

        self.bars_entry = ctk.CTkEntry(
            row1,
            width=60,
            font=("Roboto", 12),
            fg_color=ConfigCtk.BG2,
            text_color=ConfigCtk.FG,
            border_color=ConfigCtk.BG3,
            border_width=1
        )
        self.bars_entry.pack(side="left")
        self.bars_entry.delete(0, 'end')
        self.bars_entry.insert(0, str(DEFAULT_MAX_BARS))

        # Row 2: Timeframes - using centralized TIMEFRAMES
        row2 = ctk.CTkFrame(
            self.fetch_frame,
            fg_color="transparent"
        )
        row2.pack(fill="x", padx=5, pady=3)

        ctk.CTkLabel(
            row2,
            text="TF:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 3))

        self.timeframe_vars = {}

        # Create a frame for checkboxes to better control spacing
        tf_checkbox_frame = ctk.CTkFrame(row2, fg_color="transparent")
        tf_checkbox_frame.pack(side="left", fill="x", expand=True)

        # Use unique timeframes from TIMEFRAME_ORDER for checkboxes
        for tf in TIMEFRAME_ORDER:
            var = ctk.BooleanVar(value=True)
            self.timeframe_vars[tf] = var

            cb = ctk.CTkCheckBox(
                tf_checkbox_frame,
                text=tf,
                variable=var,
                font=("Roboto", 12),
                fg_color=ConfigCtk.BG2,
                border_color=ConfigCtk.BG3,
                hover_color=ConfigCtk.BG3,
                text_color=ConfigCtk.FG
            )
            cb.pack(side="left", padx=2)

        # Row 3: Indicators
        row3 = ctk.CTkFrame(
            self.fetch_frame,
            fg_color="transparent"
        )
        row3.pack(fill="x", padx=5, pady=3)

        ctk.CTkLabel(
            row3,
            text="Ind:",
            font=("Roboto", 12),
            text_color=ConfigCtk.FG_DIM
        ).pack(side="left", padx=(0, 8))

        self.indicators_vars = {}
        indicators = [
            ('MACD', 'macd'),
            ('RSI', 'rsi'),
            ('BB', 'bb'),
            ('MAs', 'mas')
        ]

        # Create a frame for indicator checkboxes
        ind_checkbox_frame = ctk.CTkFrame(row3, fg_color="transparent")
        ind_checkbox_frame.pack(side="left", fill="x", expand=True)

        for display_text, key in indicators:
            var = ctk.BooleanVar(value=False)
            self.indicators_vars[key] = var

            cb = ctk.CTkCheckBox(
                ind_checkbox_frame,
                text=display_text,
                variable=var,
                font=("Roboto", 12),
                command=self._update_indicators_config,
                fg_color=ConfigCtk.BG2,
                border_color=ConfigCtk.BG3,
                hover_color=ConfigCtk.BG3,
                text_color=ConfigCtk.FG
            )
            cb.pack(side="left", padx=5)

        # Row 4: 3-ROW TABLE for Available/Fetched bars
        self.table_frame = ctk.CTkFrame(
            self.fetch_frame,
            height=90,
            fg_color=ConfigCtk.BG2
        )
        self.table_frame.pack(fill="x", padx=5, pady=5)
        self.table_frame.pack_propagate(False)

        # Table header (Timeframes) - 12pt font
        self.table_header_label = ctk.CTkLabel(
            self.table_frame,
            text="",
            font=("Courier", 12, "bold"),
            text_color=ConfigCtk.FG
        )
        self.table_header_label.pack(fill="x", padx=2, pady=1)

        # Available bars row - 12pt font
        self.table_available_label = ctk.CTkLabel(
            self.table_frame,
            text="",
            font=("Courier", 12),
            text_color="#00FFFF",
            anchor="w"
        )
        self.table_available_label.pack(fill="x", padx=2, pady=1)

        # Fetched bars row - 12pt font
        self.table_fetched_label = ctk.CTkLabel(
            self.table_frame,
            text="",
            font=("Courier", 12, "bold"),
            text_color=ConfigCtk.GREEN,
            anchor="w"
        )
        self.table_fetched_label.pack(fill="x", padx=2, pady=1)

        # ==================== LOG FRAME ====================
        self.log_frame = ctk.CTkFrame(
            self.parent,
            fg_color=ConfigCtk.BG1,
            corner_radius=0
        )
        self.log_frame.pack(fill="both", expand=True, padx=1, pady=1)

        self.log_text = ctk.CTkTextbox(
            self.log_frame,
            height=200,
            font=("Consolas", 12),
            fg_color=ConfigCtk.BG1,
            text_color=ConfigCtk.YELLOW,
            border_color=ConfigCtk.BG3,
            border_width=1
        )
        self.log_text.pack(fill="both", expand=True, padx=5, pady=5)

        # Enable mouse wheel scrolling
        self.log_text.bind("<MouseWheel>", self._on_mousewheel)
        self.log_text.bind("<Button-4>", self._on_mousewheel)
        self.log_text.bind("<Button-5>", self._on_mousewheel)

        # Right-click menu for log
        self._setup_log_menu()

    def _fetch_selected_symbol(self):
        """Fetch data for the selected symbol only"""
        if not self.is_connected():
            self.log("❌ Not connected")
            return

        # Get selected symbol from the dropdown
        symbol = self.symbol_combo.get()
        if not symbol or symbol == "Select Symbol":
            self.log("❌ No symbol selected")
            return

        selected_tfs = self.get_selected_timeframes()
        if not selected_tfs:
            self.log("❌ Select at least one timeframe")
            return

        try:
            count = int(self.bars_entry.get())
            # Cap at DEFAULT_MAX_BARS
            if count > DEFAULT_MAX_BARS:
                count = DEFAULT_MAX_BARS
                self.bars_entry.delete(0, 'end')
                self.bars_entry.insert(0, str(DEFAULT_MAX_BARS))
                self.log(f"📊 Capping bars to {DEFAULT_MAX_BARS} (max limit)")
        except:
            count = DEFAULT_MAX_BARS
            self.bars_entry.delete(0, 'end')
            self.bars_entry.insert(0, str(DEFAULT_MAX_BARS))

        self.log(f"🚀 Fetching {count} bars for selected symbol: {symbol}")
        self.log(f"📊 Timeframes: {', '.join(selected_tfs)}")

        # Disable fetch buttons during operation
        self.fetch_btn.configure(state="disabled", text="FETCHING...")
        self.fetch_selection_btn.configure(state="disabled", text="FETCHING...")

        def fetch_thread():
            tf_results = {}
            tf_order = TIMEFRAME_ORDER

            for tf_idx, tf in enumerate(selected_tfs, 1):
                try:
                    self.log(f"  🔄 Fetching {tf} ({tf_idx}/{len(selected_tfs)})...")

                    # Request exactly the count
                    data = self.mt5_api.get_rates(symbol, tf, count)

                    if data and isinstance(data, list):
                        actual_bars = len(data)
                        tf_results[tf] = actual_bars

                        if actual_bars < count:
                            self.log(f"  ⚠️ {tf}: Got {actual_bars}/{count} bars (MT5 limit)")
                        else:
                            self.log(f"  ✅ {tf}: {actual_bars} bars")

                        # Save to CSV
                        self._save_to_csv(symbol, tf, data, actual_bars)
                    else:
                        tf_results[tf] = 0
                        self.log(f"  ❌ {tf}: No data received")

                    time.sleep(0.1)  # Be nice to server between timeframes

                except Exception as e:
                    tf_results[tf] = 0
                    self.log(f"  ❌ {tf} error: {e}")

            # Update display with results
            self.parent.after(0, self._update_fetched_display, tf_results)
            self.parent.after(0, lambda: self._update_fetch_selection_complete(tf_results, symbol))
            self.parent.after(0, lambda: self.fetch_btn.configure(state="normal", text="FETCH ALL"))
            self.parent.after(0, lambda: self.fetch_selection_btn.configure(state="normal", text="FETCH SELECTION"))

        threading.Thread(target=fetch_thread, daemon=True).start()

    def _update_fetch_selection_complete(self, tf_results, symbol):
        """Update UI after fetch completion for selected symbol"""
        total_bars = sum(tf_results.values())

        self.log(f"\n{'='*50}")
        self.log(f"✅ FETCH COMPLETE: {symbol}")
        self.log(f"📊 Total bars fetched: {total_bars}")
        self.log(f"{'='*50}")

        # Log which timeframes were fetched
        fetched_tfs = [tf for tf, bars in tf_results.items() if bars > 0]
        if fetched_tfs:
            self.log(f"  • Fetched timeframes: {', '.join(fetched_tfs)}")

    def _browse_path(self):
        """Browse for terminal executable path"""
        filename = filedialog.askopenfilename(
            title="Select MetaTrader 5 Terminal",
            filetypes=[("Executable files", "*.exe"), ("All files", "*.*")]
        )
        if filename:
            self.path_entry.delete(0, 'end')
            self.path_entry.insert(0, filename)
            self.log(f"📁 Terminal path set to: {filename}")

    def _browse_data_dir(self):
        """Browse for data directory"""
        directory = filedialog.askdirectory(
            title="Select Data Output Folder",
            initialdir=self.data_dir
        )
        if directory:
            self.data_dir = directory
            self.data_dir_label.configure(text=os.path.basename(directory))
            self.log(f"📁 Data folder set to: {directory}")

    def _on_mousewheel(self, event):
        """Handle mouse wheel scrolling"""
        if event.num == 4 or (hasattr(event, 'delta') and event.delta > 0):
            self.log_text.yview_scroll(-1, "units")
        elif event.num == 5 or (hasattr(event, 'delta') and event.delta < 0):
            self.log_text.yview_scroll(1, "units")
        return "break"

    def _setup_log_menu(self):
        """Setup right-click menu for log"""
        menu = tk.Menu(self.log_text, tearoff=0)
        menu.add_command(label="Copy", command=self._copy_log)
        menu.add_command(label="Clear", command=self._clear_log)
        self.log_text.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))

    def _copy_log(self):
        """Copy selected log text"""
        try:
            if self.log_text.tag_ranges("sel"):
                text = self.log_text.selection_get()
            else:
                text = self.log_text.get('1.0', 'end-1c')

            self.parent.clipboard_clear()
            self.parent.clipboard_append(text)
            self.log("✅ Log copied to clipboard")
        except Exception as e:
            self.log(f"❌ Copy failed: {e}")

    def _clear_log(self):
        """Clear log"""
        self.log_text.delete('1.0', 'end')

    def _on_auto_connect_change(self):
        """Handle Auto Connect checkbox change"""
        if self.auto_connect_var.get():
            self.log("Auto Connect enabled")
        else:
            self.log("Auto Connect disabled")

    def _on_mw_symbol_selected(self, choice=None):
        """Handle Market Watch symbol selection - RESET and start 5 updates"""
        selected_symbol = self.mw_symbol_var.get()
        if selected_symbol and selected_symbol != "Select Symbol":
            # Stop any existing rate updates
            self._stop_rate_updates()

            # Reset counter
            self.rate_update_count = 0
            self.current_rate_symbol = selected_symbol

            self.log(f"🎯 Selected Market Watch symbol: {selected_symbol}")
            self.log(f"📊 Will fetch bid/ask {self.max_rate_updates} times")

            # Start first update immediately
            self._update_rate_display()

        else:
            self.current_rate_symbol = None
            self.rate_label.configure(text="Rate: N/A")
            self._stop_rate_updates()

    def _stop_rate_updates(self):
        """Stop all scheduled rate updates"""
        if self.rate_update_job:
            self.parent.after_cancel(self.rate_update_job)
            self.rate_update_job = None
        self.rate_update_count = 0

    def _update_rate_display(self):
        """Update the rate display with current bid/ask - LIMITED to max updates"""
        if not self.current_rate_symbol or not self.is_connected():
            self.rate_label.configure(text="Rate: N/A")
            return

        # Check if we've reached the maximum number of updates
        if self.rate_update_count >= self.max_rate_updates:
            self.rate_label.configure(
                text=f"Rate: {self.current_rate_symbol} - Completed {self.max_rate_updates} updates",
                text_color=ConfigCtk.GREEN
            )
            self.log(f"✅ Completed {self.max_rate_updates} bid/ask updates for {self.current_rate_symbol}")
            self.rate_update_job = None
            return

        try:
            # Increment counter BEFORE update
            self.rate_update_count += 1

            # Use MT5API method directly
            price_data = self.mt5_api.get_current_price(self.current_rate_symbol)

            if price_data and 'bid' in price_data and 'ask' in price_data:
                bid = float(price_data['bid'])
                ask = float(price_data['ask'])
                spread = round((ask - bid) * 10000, 1)

                # Format timestamp
                timestamp = datetime.now().strftime("%H:%M:%S")

                # Log bid/ask to log window
                log_msg = f"[{timestamp}] {self.current_rate_symbol}: Bid={bid:.5f} Ask={ask:.5f} ({self.rate_update_count}/{self.max_rate_updates})"
                self.log_text.insert('end', f"{log_msg}\n")
                self.log_text.see('end')

                rate_text = f"{self.current_rate_symbol}:  BID={bid:.5f}  ASK={ask:.5f}  SPREAD={spread}"
                self.rate_label.configure(text=rate_text)

                # Change color based on spread
                if spread <= 1.0:
                    self.rate_label.configure(text_color=ConfigCtk.GREEN)
                elif spread <= 5.0:
                    self.rate_label.configure(text_color=ConfigCtk.YELLOW)
                else:
                    self.rate_label.configure(text_color=ConfigCtk.RED)
            else:
                self.rate_label.configure(text=f"Rate: No data for {self.current_rate_symbol}")
                self.log(f"⚠️ No price data for {self.current_rate_symbol}")

            # Schedule next update ONLY if we haven't reached the max
            if self.rate_update_count < self.max_rate_updates:
                self.rate_update_job = self.parent.after(self.rate_update_interval, self._update_rate_display)
            else:
                self.rate_update_job = None
                self.log(f"⏹️ Stopped updates for {self.current_rate_symbol} after {self.max_rate_updates} requests")

        except Exception as e:
            self.rate_label.configure(text=f"Rate: Error - {str(e)[:30]}...")
            self.log(f"⚠️ Rate update error: {e}")

            # Schedule next update even on error (unless we've reached max)
            if self.rate_update_count < self.max_rate_updates:
                self.rate_update_job = self.parent.after(self.rate_update_interval, self._update_rate_display)

    def _load_config(self):
        """Load configuration from file"""
        defaults = {
            'mt5_path': '',
            'auto_connect': 'false',
            'data_dir': DEFAULT_DATA_DIR
        }

        if not os.path.exists(self.config_file):
            return defaults

        try:
            config = configparser.ConfigParser()
            config.read(self.config_file)
            loaded = defaults.copy()

            if 'MT5' in config:
                for key in ['mt5_path', 'auto_connect', 'data_dir']:
                    if key in config['MT5']:
                        loaded[key] = config['MT5'][key]

            return loaded
        except:
            return defaults

    def _apply_config(self):
        """Apply loaded configuration to UI"""
        if 'mt5_path' in self.saved_state:
            self.path_entry.delete(0, 'end')
            self.path_entry.insert(0, self.saved_state['mt5_path'])

        if 'auto_connect' in self.saved_state:
            auto_connect = self.saved_state['auto_connect'].lower() == 'true'
            self.auto_connect_var.set(auto_connect)

        if 'data_dir' in self.saved_state and self.saved_state['data_dir']:
            self.data_dir = self.saved_state['data_dir']
            self.data_dir_label.configure(text=os.path.basename(self.data_dir))

    def save_config(self):
        """Save current configuration"""
        config = configparser.ConfigParser()

        config['MT5'] = {
            'mt5_path': self.path_entry.get(),
            'auto_connect': str(self.auto_connect_var.get()),
            'data_dir': self.data_dir
        }

        try:
            with open(self.config_file, 'w') as f:
                config.write(f)
            self.log("✅ Configuration saved")
        except Exception as e:
            self.log(f"❌ Save error: {e}")

    def log(self, message: str):
        """Log message to UI"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert('end', f"[{timestamp}] {message}\n")
        self.log_text.see('end')

    def update_symbol_dropdowns(self, market_watch_symbols=None, all_symbols=None):
        """Update the symbol dropdowns with new data"""
        if market_watch_symbols is not None:
            self.mw_symbol_combo.configure(values=market_watch_symbols)
            if market_watch_symbols:
                self.mw_symbol_combo.set(market_watch_symbols[0])
                # Reset counter and start 5 updates
                self._stop_rate_updates()
                self.rate_update_count = 0
                self.current_rate_symbol = market_watch_symbols[0]
                self._update_rate_display()

                # Log how many symbols with extensions are included
                ext_symbols = [s for s in market_watch_symbols if '.' in str(s)]
                if ext_symbols:
                    self.log(f"📊 Includes {len(ext_symbols)} symbols with extensions: {ext_symbols[:5]}")

        if all_symbols is not None:
            self.all_symbols_combo.configure(values=all_symbols)
            if all_symbols:
                self.all_symbols_combo.set(all_symbols[0])

                # Log how many symbols with extensions are included
                ext_symbols = [s for s in all_symbols if '.' in str(s)]
                if ext_symbols:
                    self.log(f"📊 Includes {len(ext_symbols)} symbols with extensions: {ext_symbols[:5]}")

    def get_selected_market_watch_symbol(self):
        """Get the currently selected Market Watch symbol"""
        return self.mw_symbol_var.get()

    def get_selected_all_symbol(self):
        """Get the currently selected All Symbols symbol"""
        return self.all_symbols_var.get()

    def _connect_mt5(self):
        """Connect to MT5 directly"""
        self.connect_btn.configure(state="disabled", text="Connecting...")

        def connect_thread():
            try:
                path = self.path_entry.get().strip() or None

                self.log(f"Connecting to MT5...")

                # Create MT5API instance
                self.mt5_api = MT5API(path=path)

                # Attempt connection using MT5API method
                if self.mt5_api.initialize():
                    self.connected = True

                    # Fetch symbols using MT5API methods
                    try:
                        market_watch_symbols = self.mt5_api.get_market_watch_symbols()
                        all_symbols = self.mt5_api.get_all_symbols()
                        self._schedule_gui_update(self._update_symbols_gui, market_watch_symbols, all_symbols)
                    except Exception as e:
                        self.log(f"⚠️ Failed to fetch symbols: {e}")
                    self._schedule_gui_update(self._on_connect_success)
                else:
                    self._schedule_gui_update(self._on_connect_failure, "Connection failed")

            except Exception as e:
                self._schedule_gui_update(self._on_connect_failure, str(e))

        threading.Thread(target=connect_thread, daemon=True).start()

    def _update_symbols_gui(self, market_watch_symbols, all_symbols):
        """Update GUI with symbols (called in main thread)"""
        self.update_symbol_dropdowns(market_watch_symbols, all_symbols)
        if market_watch_symbols:
            self.log(f"✅ Loaded {len(market_watch_symbols)} Market Watch symbols")
        if all_symbols:
            self.log(f"✅ Loaded {len(all_symbols)} all symbols")

        # Also update the symbol selection dropdown
        if market_watch_symbols:
            self.symbol_combo.configure(values=market_watch_symbols)
            self.symbol_combo.set(market_watch_symbols[0])
            self.refresh_symbols_btn.configure(state="normal")
            self.fetch_btn.configure(state="normal")
            self.fetch_selection_btn.configure(state="normal")  # NEW: Enable fetch selection button
            # Auto-verify available bars for first symbol
            self.parent.after(100, self._on_symbol_selected)

    def _schedule_gui_update(self, method, *args):
        """Schedule a GUI update in the main thread"""
        self.parent.after(0, lambda: method(*args))

    def _on_connect_success(self):
        """Handle successful connection"""
        self.connect_btn.configure(state="disabled", text="Connected")
        self.disconnect_btn.configure(state="normal")
        self.log("✅ MT5 connected successfully")

        # Save config and call callback
        self.save_config()
        if self.on_connect_callback:
            self.on_connect_callback(self.mt5_api)

    def _on_connect_failure(self, error: str):
        """Handle connection failure"""
        self.connect_btn.configure(state="normal", text="Connect")
        self.disconnect_btn.configure(state="disabled")
        self.log(f"❌ Connection failed: {error}")

    def _disconnect_mt5(self):
        """Disconnect from MT5"""
        # Stop rate updates
        self._stop_rate_updates()

        # Clear rate display
        self.rate_label.configure(text="Rate: N/A")
        self.current_rate_symbol = None

        if self.mt5_api:
            try:
                self.log("Disconnecting from MT5...")
                self.mt5_api.shutdown()
                self.log("✅ MT5 disconnected")
            except Exception as e:
                self.log(f"⚠️ Error during disconnect: {e}")
            finally:
                self.mt5_api = None

        # Update GUI state
        self.connected = False
        self.connect_btn.configure(state="normal", text="Connect")
        self.disconnect_btn.configure(state="disabled")

        # Clear symbol dropdowns
        self.mw_symbol_combo.set("Select Symbol")
        self.all_symbols_combo.set("Select Symbol")
        self.mw_symbol_combo.configure(values=["Select Symbol"])
        self.all_symbols_combo.configure(values=["Select Symbol"])
        self.symbol_combo.configure(values=["Select Symbol"])
        self.symbol_combo.set("Select Symbol")
        self.refresh_symbols_btn.configure(state="disabled")
        self.fetch_btn.configure(state="disabled")

        # Clear table
        self.table_header_label.configure(text="")
        self.table_available_label.configure(text="")
        self.table_fetched_label.configure(text="")

        # Save config and call callback
        self.save_config()
        if self.on_disconnect_callback:
            self.on_disconnect_callback()

    def get_api(self):
        """Get the MT5API instance"""
        return self.mt5_api

    def is_connected(self):
        """Check if connected"""
        return self.connected and self.mt5_api and self.mt5_api.is_connected

    def set_callbacks(self, on_connect=None, on_disconnect=None):
        """Set connection callbacks"""
        self.on_connect_callback = on_connect
        self.on_disconnect_callback = on_disconnect

    def refresh_prices(self):
        """Manually trigger another 5 updates for current symbol"""
        if self.current_rate_symbol and self.is_connected():
            self._stop_rate_updates()
            self.rate_update_count = 0
            self.log(f"🔄 Manual refresh - fetching {self.max_rate_updates} updates for {self.current_rate_symbol}")
            self._update_rate_display()
            return True
        return False

    # ==================== SYMBOL SELECTION METHODS ====================

    def _select_all_timeframes(self):
        """Select all timeframe checkboxes"""
        for var in self.timeframe_vars.values():
            var.set(True)
        self.log("✅ All timeframes selected")

    def _deselect_all_timeframes(self):
        """Deselect all timeframe checkboxes"""
        for var in self.timeframe_vars.values():
            var.set(False)
        self.log("✅ All timeframes deselected")

    def get_selected_timeframes(self):
        """Get list of selected timeframes"""
        selected = []
        for tf, var in self.timeframe_vars.items():
            if var.get():
                selected.append(tf)
        return selected

    def get_selected_indicators(self):
        """Get dictionary of selected indicators"""
        return {
            'macd': self.indicators_vars['macd'].get(),
            'rsi': self.indicators_vars['rsi'].get(),
            'bb': self.indicators_vars['bb'].get(),
            'mas': self.indicators_vars['mas'].get()
        }

    def _update_indicators_config(self):
        """Update indicators configuration"""
        indicators_config = self.get_selected_indicators()
        selected = [name for name, selected in indicators_config.items() if selected]
        if selected:
            self.log(f"📊 Indicators enabled: {', '.join(selected)}")
        else:
            self.log("📊 Indicators disabled")

    def _refresh_symbols(self):
        """Refresh symbols list"""
        if not self.is_connected():
            self.log("❌ Not connected")
            return

        def get_thread():
            self.log("📋 Fetching symbols...")
            try:
                symbols = self.mt5_api.get_market_watch_symbols()
                if symbols:
                    self.parent.after(0, self._update_symbols_dropdown, symbols)
                    self.log(f"✅ Got {len(symbols)} symbols")
                else:
                    self.log("❌ No symbols received")
            except Exception as e:
                self.log(f"❌ Error fetching symbols: {e}")

        threading.Thread(target=get_thread, daemon=True).start()

    def _update_symbols_dropdown(self, symbols):
        """Update symbols dropdown"""
        self.symbol_combo.configure(values=symbols)
        if symbols:
            self.symbol_combo.set(symbols[0])
            # Auto-verify available bars for first symbol
            self.parent.after(100, self._on_symbol_selected)

    def _on_symbol_selected(self, choice=None):
        """When symbol is selected, verify available bars"""
        if not self.is_connected():
            return

        symbol = self.symbol_combo.get()
        if not symbol or symbol == "Select Symbol":
            return

        selected_tfs = self.get_selected_timeframes()
        if not selected_tfs:
            return

        def verify_thread():
            self.log(f"🔍 Checking available bars for {symbol}...")

            tf_order = TIMEFRAME_ORDER
            available = {}

            for tf in selected_tfs:
                try:
                    # Request large number to see what's available
                    data = self.mt5_api.get_rates(symbol, tf, DEFAULT_MAX_BARS)
                    if data and isinstance(data, list):
                        available[tf] = len(data)
                    else:
                        available[tf] = 0
                    time.sleep(0.2)  # Be nice to server
                except Exception as e:
                    available[tf] = 0
                    self.log(f"⚠️ Error checking {tf}: {e}")

            self.parent.after(0, self._update_available_display, available)

        threading.Thread(target=verify_thread, daemon=True).start()

    def _update_available_display(self, available):
        """Update the available bars display in table - properly aligned with headers"""

        tf_order = TIMEFRAME_ORDER

        # Define column widths for perfect alignment
        col_width = 8  # Fixed width for all columns

        # Create header with proper spacing
        header = "TF:"
        for tf in tf_order:
            # Center the timeframe in the column
            padding = col_width - len(tf)
            left_pad = padding // 2
            right_pad = padding - left_pad
            header += " " * left_pad + tf + " " * right_pad
        self.table_header_label.configure(text=header)

        # Create available bars row with perfect alignment
        available_row = "Avail:"
        for tf in tf_order:
            bars = available.get(tf, 0)
            if bars > 0:
                # Format bars with K/M suffix if needed for compact display
                if bars >= 1000000:
                    bars_str = f"{bars/1000000:.1f}M"
                elif bars >= 1000:
                    bars_str = f"{bars/1000:.1f}K"
                else:
                    bars_str = str(bars)

                # Right-align within column
                padding = col_width - len(bars_str)
                available_row += " " * padding + bars_str
            else:
                # Show N/A centered in column
                na_text = "N/A"
                padding = col_width - len(na_text)
                left_pad = padding // 2
                right_pad = padding - left_pad
                available_row += " " * left_pad + na_text + " " * right_pad
        self.table_available_label.configure(text=available_row)

        # Clear fetched row with proper spacing
        fetched_row = "Fetched:"
        for tf in tf_order:
            fetched_row += " " * col_width
        self.table_fetched_label.configure(text=fetched_row)

        # Log results
        self.log("📊 Available bars:")
        for tf in tf_order:
            if tf in available and available[tf] > 0:
                self.log(f"   • {tf}: {available[tf]} bars")

    def _update_fetched_display(self, fetched):
        """Update the fetched bars display in table - properly aligned with headers"""

        tf_order = TIMEFRAME_ORDER

        # Define column widths for perfect alignment (must match _update_available_display)
        col_width = 8

        # Create fetched bars row with perfect alignment
        fetched_row = "Fetched:"
        for tf in tf_order:
            bars = fetched.get(tf, 0)
            if bars > 0:
                # Format bars with K/M suffix if needed for compact display
                if bars >= 1000000:
                    bars_str = f"{bars/1000000:.1f}M"
                elif bars >= 1000:
                    bars_str = f"{bars/1000:.1f}K"
                else:
                    bars_str = str(bars)

                # Right-align within column
                padding = col_width - len(bars_str)
                fetched_row += " " * padding + bars_str
            else:
                # Show N/A centered in column
                na_text = "N/A"
                padding = col_width - len(na_text)
                left_pad = padding // 2
                right_pad = padding - left_pad
                fetched_row += " " * left_pad + na_text + " " * right_pad
        self.table_fetched_label.configure(text=fetched_row)

        # Log summary
        self.log("🎯 Fetch complete!")

    def _fetch_batch(self):
        """Legacy fetch for single symbol - kept for backward compatibility"""
        self._fetch_all_symbols()  # Redirect to new method

    def _fetch_all_symbols(self):
        """Fetch data for ALL Market Watch symbols"""
        if not self.is_connected():
            self.log("❌ Not connected")
            return

        # Get all Market Watch symbols
        symbols = self.mt5_api.get_market_watch_symbols()
        if not symbols:
            self.log("❌ No Market Watch symbols available")
            return

        selected_tfs = self.get_selected_timeframes()
        if not selected_tfs:
            self.log("❌ Select at least one timeframe")
            return

        try:
            count = int(self.bars_entry.get())
            # Cap at DEFAULT_MAX_BARS
            if count > DEFAULT_MAX_BARS:
                count = DEFAULT_MAX_BARS
                self.bars_entry.delete(0, 'end')
                self.bars_entry.insert(0, str(DEFAULT_MAX_BARS))
                self.log(f"📊 Capping bars to {DEFAULT_MAX_BARS} (max limit)")
        except:
            count = DEFAULT_MAX_BARS
            self.bars_entry.delete(0, 'end')
            self.bars_entry.insert(0, str(DEFAULT_MAX_BARS))

        self.log(f"🚀 Fetching {count} bars for ALL {len(symbols)} Market Watch symbols")
        self.log(f"📊 Timeframes: {', '.join(selected_tfs)}")

        # Disable fetch button during operation
        self.fetch_btn.configure(state="disabled", text="FETCHING...")

        def fetch_thread():
            results = {}
            tf_order = TIMEFRAME_ORDER

            for symbol_idx, symbol in enumerate(symbols, 1):
                self.log(f"\n📈 Processing symbol {symbol_idx}/{len(symbols)}: {symbol}")
                symbol_results = {}

                for tf_idx, tf in enumerate(selected_tfs, 1):
                    try:
                        self.log(f"  🔄 Fetching {tf} ({tf_idx}/{len(selected_tfs)})...")

                        # Request exactly the count
                        data = self.mt5_api.get_rates(symbol, tf, count)

                        if data and isinstance(data, list):
                            actual_bars = len(data)
                            symbol_results[tf] = actual_bars

                            if actual_bars < count:
                                self.log(f"  ⚠️ {tf}: Got {actual_bars}/{count} bars (MT5 limit)")
                            else:
                                self.log(f"  ✅ {tf}: {actual_bars} bars")

                            # Save to CSV
                            self._save_to_csv(symbol, tf, data, actual_bars)
                        else:
                            symbol_results[tf] = 0
                            self.log(f"  ❌ {tf}: No data received")

                        time.sleep(0.1)  # Be nice to server between timeframes

                    except Exception as e:
                        symbol_results[tf] = 0
                        self.log(f"  ❌ {tf} error: {e}")

                results[symbol] = symbol_results
                time.sleep(0.2)  # Be nice to server between symbols

            # Update display with first symbol's results for visual feedback
            if symbols and symbols[0] in results:
                self.parent.after(0, self._update_fetched_display, results[symbols[0]])

            self.parent.after(0, self._update_fetch_complete, results, len(symbols))
            self.parent.after(0, lambda: self.fetch_btn.configure(state="normal", text="FETCH ALL"))

        threading.Thread(target=fetch_thread, daemon=True).start()

    def _update_fetch_complete(self, results, total_symbols):
        """Update UI after fetch completion"""
        # Calculate total bars fetched
        total_bars = 0
        for symbol_results in results.values():
            total_bars += sum(symbol_results.values())

        self.log(f"\n{'='*50}")
        self.log(f"✅ FETCH COMPLETE: Processed {total_symbols} symbols")
        self.log(f"📊 Total bars fetched: {total_bars}")
        self.log(f"{'='*50}")

        # Log summary per symbol
        for symbol, tf_results in results.items():
            fetched_tfs = [tf for tf, bars in tf_results.items() if bars > 0]
            if fetched_tfs:
                self.log(f"  • {symbol}: {len(fetched_tfs)} timeframes")

    def _save_to_csv(self, symbol, timeframe, data, actual_bars):
        """Save data to CSV file with SYMBOL_TF.csv naming convention in selected data folder"""
        try:
            import pandas as pd
            from datetime import datetime

            # Create data folder if it doesn't exist
            if not os.path.exists(self.data_dir):
                os.makedirs(self.data_dir)
                self.log(f"📁 Created data folder: {self.data_dir}")

            # Clean the symbol name for folder (remove problematic characters)
            safe_symbol = symbol.replace('/', '_').replace('.', '_').replace('\\', '_')

            # Create symbol sub-folder inside data directory
            symbol_dir = os.path.join(self.data_dir, safe_symbol)
            if not os.path.exists(symbol_dir):
                os.makedirs(symbol_dir)

            # Convert to DataFrame
            df = pd.DataFrame(data)

            # Filename format: SYMBOL_TF.csv (e.g., EURUSD_D1.csv)
            filename = f"{safe_symbol}_{timeframe}.csv"
            filepath = os.path.join(symbol_dir, filename)

            # If file exists, overwrite it (no timestamp added)
            if os.path.exists(filepath):
                rel_path = os.path.relpath(filepath, os.path.expanduser("~"))
                self.log(f"   ⚠️ File exists, overwriting: ~/{rel_path}")
            else:
                rel_path = os.path.relpath(filepath, os.path.expanduser("~"))
                self.log(f"   💾 Saved {actual_bars} bars to ~/{rel_path}")

            df.to_csv(filepath, index=False)

        except Exception as e:
            self.log(f"   ❌ Save error for {timeframe}: {e}")

# ==================== STANDALONE MODE ====================
class StandaloneMode:
    """
    Standalone GUI mode that creates its own window using CustomTkinter.
    Directly controls MT5API.
    """

    def __init__(self, root_window=None, config_file="mt5_api_direct.ini"):
        """
        Initialize standalone mode.

        Args:
            root_window: Optional existing Tkinter root window
            config_file: Configuration file path
        """
        self.root = root_window or ctk.CTk()
        self.root.title("MT5 Direct API Client")

        # Apply root window styling
        self.root.configure(fg_color=ConfigCtk.BG0)

        # Fixed window dimensions from ConfigCtk
        self.root.geometry(f"{ConfigCtk.WIN_W}x{ConfigCtk.WIN_H}")
        self.root.minsize(ConfigCtk.WIN_W, ConfigCtk.WIN_H)
        self.root.maxsize(ConfigCtk.WIN_W, ConfigCtk.WIN_H)
        self.root.resizable(False, False)

        # Load window state from config (but override with fixed dimensions)
        self.saved_window_state = self._load_window_config(config_file)

        # Create main container with root background
        main_container = ctk.CTkFrame(
            self.root,
            fg_color=ConfigCtk.BG0,
            corner_radius=0
        )
        main_container.pack(fill="both", expand=True, padx=0, pady=0)

        # Create MT5APIEmbed instance for the GUI functionality
        self.gui = MT5APIEmbed(main_container, config_file=config_file)

        # Setup window close handler with confirmation
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        # Log startup message
        self.gui.log("Standalone Mode initialized - Dark Industrial theme with Amber accent")
        self.gui.log("Direct MT5 API - No login/password required")

    def _load_window_config(self, config_file):
        """Load window-specific configuration (but ignore for dimensions)"""
        defaults = {
            'window_width': str(ConfigCtk.WIN_W),
            'window_height': str(ConfigCtk.WIN_H)
        }

        if not os.path.exists(config_file):
            return defaults

        try:
            config = configparser.ConfigParser()
            config.read(config_file)
            loaded = defaults.copy()

            # Still load config but dimensions will be overridden
            if 'Window' in config:
                for key in ['window_width', 'window_height']:
                    if key in config['Window']:
                        loaded[key] = config['Window'][key]

            return loaded
        except:
            return defaults

    def save_config(self):
        """Save standalone configuration including window size"""
        # Save bridge config using EmbedMode method
        self.gui.save_config()

        # Then save window state (but dimensions will always be from ConfigCtk)
        try:
            config = configparser.ConfigParser()
            config.read(self.gui.config_file)

            # Update window section with dimensions from ConfigCtk
            if 'Window' not in config:
                config['Window'] = {}
            config['Window']['window_width'] = str(ConfigCtk.WIN_W)
            config['Window']['window_height'] = str(ConfigCtk.WIN_H)

            with open(self.gui.config_file, 'w') as f:
                config.write(f)

            self.gui.log("✅ Configuration saved")
        except Exception as e:
            self.gui.log(f"❌ Save error: {e}")

    def _on_closing(self):
        """Handle window closing with confirmation - auto-saves configuration"""
        # Show exit confirmation dialog
        if messagebox.askokcancel("Exit", "Are you sure you want to exit?"):
            # Auto-save configuration
            self.save_config()

            # Disconnect if connected
            if self.gui.mt5_api:
                try:
                    self.gui.mt5_api.shutdown()
                except:
                    pass
            self.root.destroy()

    def run(self):
        """Run the standalone application"""
        self.root.mainloop()

    # Proxy methods to EmbedMode for easy access
    def log(self, message: str):
        """Log message"""
        self.gui.log(message)

    def get_api(self):
        """Get the MT5API instance"""
        return self.gui.get_api()

    def is_connected(self):
        """Check if connected"""
        return self.gui.is_connected()

    def get_selected_market_watch_symbol(self):
        """Get the currently selected Market Watch symbol"""
        return self.gui.get_selected_market_watch_symbol()

    def get_selected_all_symbol(self):
        """Get the currently selected All Symbols symbol"""
        return self.gui.get_selected_all_symbol()

    def update_symbol_dropdowns(self, market_watch_symbols=None, all_symbols=None):
        """Update the symbol dropdowns with new data"""
        self.gui.update_symbol_dropdowns(market_watch_symbols, all_symbols)

    def set_callbacks(self, on_connect=None, on_disconnect=None):
        """Set connection callbacks"""
        self.gui.set_callbacks(on_connect, on_disconnect)

# ==================== MAIN ENTRY POINT ====================
def setup_ctk_theme():
    """Apply CTk theme configuration"""
    ctk.set_appearance_mode(ConfigCtk.APPEARANCE_MODE)
    ctk.set_default_color_theme(ConfigCtk.COLOR_THEME)

def launch_mt5_api_client():
    """Launch standalone GUI"""
    setup_ctk_theme()
    app = StandaloneMode()
    app.run()

if __name__ == "__main__":
    launch_mt5_api_client()